package com.exam.exception;

public class AdminTException extends Exception {
    public AdminTException(String message){
        super(message);
    }
}
